<footer class="footer">
    {{-- <div class="container">&copy; 2018 <a href="http://bixbite.site/" target="_blank">BixBite CMS</a></div> --}}
</footer>

<div id="modal_dialog" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
